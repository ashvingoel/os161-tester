#include <unistd.h>
#include <stdio.h>

int
main(void)
{
        printf("printf works!\n");
	return 0;
}
